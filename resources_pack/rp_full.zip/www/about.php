<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Using TfEL for Learning Design</title>
<link href="/css/style_master.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="container"></div>
<h1>Using TfEL for Learning Design</h1>
<center>Version: 1.00
<p>Developed by <a href="http://beaconsfieldit.net/">Beaconsfield IT</a></p></center>
</body>
</html>
