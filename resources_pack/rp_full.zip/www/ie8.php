<html>
<body bgcolor="#F0F0F0">
<center><div style="clear:both;"><br /><br /><br /><img src="http://learningdesign.sa.edu.au/images/map_screen/not_supported@2x.jpg" width="960px" height="121px" /><br /><br /><br /><br /><br /><a href="http://google.com/chrome" target="_blank"><img src="http://learningdesign.sa.edu.au/images/map_screen/get_chrome@2x.gif" width="540px" height="145px" /></a><br /><br /><br /><br /><br /><a href="http://apple.com/safari" target="_blank"><img src="http://learningdesign.sa.edu.au/images/map_screen/get_safari@2x.gif" width="540px" height="145px" /></a><br /><br /><br /><br /><br />
<div style="color: #666659;"><p>If you prefer you can download a copy of the resource <a href="#" style="color:#666659;">here</a>.</p></div></div></center>
</body>
</html>