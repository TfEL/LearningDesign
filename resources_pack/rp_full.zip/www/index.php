<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Using TfEL for Learning Design</title>
<meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; user-scalable=no; width=device-width">
<link rel="apple-touch-icon-precomposed" href="128_appIcon.png">
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<link href="/css/style_master.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="/style/add2home.css">
<script type="text/javascript" src="/src/add2home.js" charset="utf-8"></script>

<meta name="apple-mobile-web-app-title" content="TfEL LD">

</head>
<body>
<?php $IE6 = (ereg('MSIE 6',$_SERVER['HTTP_USER_AGENT'])) ? true : false;
    $IE7 = (ereg('MSIE 7',$_SERVER['HTTP_USER_AGENT'])) ? true : false;
    $IE8 = (ereg('MSIE 8',$_SERVER['HTTP_USER_AGENT'])) ? true : false;
    $FX = (ereg('Firefox',$_SERVER['HTTP_USER_AGENT'])) ? true : false;

if (($IE6 == 1) || ($IE7 == 1) || ($IE8 == 1) || ($FX == 1)) {
 // Do fallback stuff that old browsers can do here
   echo "<meta http-equiv='refresh' content='0;URL=\"http://learningdesign.sa.edu.au/ie8.php\"'>";

} else { ?>

<div class="container"></div>
<h1>Using TfEL for Learning Design</h1>
<?php 
	if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone') || strstr($_SERVER['HTTP_USER_AGENT'],'iPad')) { echo "<script type='text/javascript'>
                if (window.navigator.standalone == true) {
                    document.location.href = 'splash.php';
                }
        </script>"; }
	else { echo "<p><h1><span><a onclick=\"window.open('splash.php','popUpWindow','height=780,width=1024,resizable=no,scrollbars=no,toolbar=no,menubar=no,location=no,directories=no,status=no');\">Launch App</a></h1></span></p>"; }
?>
<?php } ?>
</body>
</html>

