<!doctype html>
<html>
<head>
<?php require("header.inc"); ?>
</head>

<body>
<div id="map_screen_master_container"> 

	<div id="map_screen_padding_topmost"></div>
    
    	<div id="map_screen_row_1"> 

			<a href="why_important.php?from=MapScreen_PH"><div id="map_screen_map_1"> </div></a>
            <a href="this_level.php?from=MapScreen_PH"><div id="map_screen_map_3"> </div></a>
            <a href="engage_learning.php?from=MapScreen_PH"><div id="map_screen_map_5"> </div></a> </div>

		
	<div id="map_screen_padding_mid"> </div>
		
		<div id="map_screen_row_2"> 
        	
            <a href="they_bring.php?from=MapScreen_PH"><div id="map_screen_map_2"> </div></a>
            <a href="evidence_assess.php?from=MapScreen_PH"><div id="map_screen_map_4"> </div></a>
            <a href="design_tlp.php?ms=6?from=MapScreen_PH"><div id="map_screen_map_6"> </div></a> </div>

<a href="/splash.php?ms=0&track=1"><div id="map_screen_home_button"> </div></a>
</div>
</body>
</html>

<!-- Now feeds "MapScreen_PH" spooler on map top levels. Each page then calls a _functions set which pools a PHP version of the page. --> 