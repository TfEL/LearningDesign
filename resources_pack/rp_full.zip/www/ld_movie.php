<!doctype html>
<html>
<head>
<?php require("header.inc"); ?>
<style type="text/css">
<!--
a:link { color: #000; text-decoration: none; }
a:visited { color: #000; text-decoration: none; }
a:hover { color: #000; text-decoration: none; }
a:active { color: #000; text-decoration: none; }
-->
</style>
</head>

<body>
<div style="color: #000; text-align:center; display:block; -webkit-border-radius: 3px; -moz-border-radius: 3px; border-radius: 3px; width: 1020px; background: #fff; margin-left: auto; margin-right: auto;"><a href="/splash.php">Go Back</a></div>
<iframe width="1024" height="750" src="http://www.youtube.com/embed/uPQMHF3csAI" frameborder="0" allowfullscreen></iframe>
</body>
</html>
