<!doctype html>
<html>
<head>
<?php require("header.inc"); ?>
</head>

<body>
<div id="splash_screen_master_container">
<div id="splash_screen_padding_topmost"> </div>
<a href="/ld_map.php"><div id="splash_screen_ld_using_strat_from_the_tfel_fw_guide_dvd"> </div></a>
<div id="splash_screen_padding_mid"> </div>
<a href="/ld_movie.php"><div id="splash_screen_using_tfel_for_ld_in_a_plc_movie"> </div></a>
</div>
</body>
</html>
